# SchoolSync

Welcome to SchoolSync! This is an application developed by Nimai Belur, Vasudha Narayanan, and Aarushi Verma, that offers a secure location for schools to keep track of their business and community partners. We offer login and logout functionality for security, as well as the ability to add, remove, search, and filter business and community partners. 